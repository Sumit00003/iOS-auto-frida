# iOS Auto Frida

A USB-first Frida automation helper for iOS app security testing,
structured the same way as the Android Auto-Frida tool but adapted to
how Frida actually works on iOS.

**Use only on devices and apps you own or are explicitly authorized to
test (e.g. your own app in development, or a client app under a signed
pentest engagement).**

## How this differs from the Android version

| Android tool | iOS tool |
|---|---|
| Detects device via `adb devices` | Detects device via Frida's USB device enumeration (usbmuxd) |
| Downloads `frida-server` binary matching device arch | Never installs anything — Frida must already be installed on-device via Sileo/Cydia/Zebra |
| Pushes binary to `/data/local/tmp`, `chmod`s it, launches it over ADB shell | No lifecycle management at all — Frida's on-device daemon starts on its own once installed |
| 3-layer validation: process / port / protocol handshake | Single check: run the same enumeration `frida-ps -U` does (`enumerate_processes()`) — if it succeeds, Frida's installed; if it raises, it isn't |
| Root vs non-root logic (`su -c`) | Jailbroken-only — a non-jailbroken device without Frida injected into the app itself won't expose a Frida daemon at all |
| Bypass scripts target Android (SSL pinning, RootBeer, SafetyNet, Xamarin, Flutter, etc.) | Bypass scripts target iOS equivalents (jailbreak detection, SecTrust-based pinning, ptrace/sysctl anti-debug) |

## Requirements

- A jailbroken iOS device with Frida installed (Sileo/Cydia repo:
  `https://build.frida.re`), or a target app repackaged with a Frida
  Gadget.
- The device connected to your computer over USB, unlocked, and
  "Trust This Computer" accepted.
- Python 3.9+ with `pip install -r requirements.txt`.

## Usage

```bash
python3 ios_auto_frida.py            # attach to a running app
python3 ios_auto_frida.py --spawn    # launch the app fresh, suspended, then hook before it runs
```

The tool will:

1. Confirm a device is present over USB.
2. Confirm Frida is installed by running the same check `frida-ps -U`
   would (and tell you to install it via Sileo/Cydia/Zebra if it
   isn't — it never tries to install anything for you).
3. Print basic device info (name, iOS version, arch).
4. List installed apps so you can pick a target.
5. List available hook scripts in `js_scripts/` so you can pick one,
   several, or all of them.
6. Attach/spawn, load the combined script, and stream `send()` output
   from the hooks to your terminal until you press Ctrl+C.

## Hook scripts

Drop any additional `.js` Frida scripts into `js_scripts/` — they show
up automatically in the picker. The included scripts are:

- `enumerate_basic_info.js` — sanity-check hook, prints bundle id/version.
- `detection_recon.js` — **passive, patches nothing.** Now logs across
  every technique family: jailbreak indicators; `Security.framework`
  cert/trust APIs (`SecTrustEvaluate`, `SecCertificateCopyData`,
  `SecTrustCopyKey`, etc.); URL Loading System delegate methods on
  whichever class actually implements them; presence of third-party
  libraries (AFNetworking, Alamofire, TrustKit, Starscream, gRPC,
  CocoaAsyncSocket, ASIHTTPRequest); sampled `memcmp`/`CC_SHA256` calls
  (manual pinning signature); bundled native TLS libraries
  (OpenSSL/BoringSSL/LibreSSL) and their verify calls;
  `Network.framework` entry points; and proxy-configuration checks.
  Run this first so you know which bypass scripts are actually
  relevant before loading all of them blind.
- `bypass_jailbreak_detection.js` — covers file-existence/`stat`-family
  checks against ~30 known jailbreak paths/binaries, URL-scheme checks
  (`cydia://`, `sileo://`, etc.), out-of-sandbox write-test checks,
  `fork()`/`system()`/`popen()` probes, and `getenv()` checks for
  injected-library environment variables.
- `bypass_ssl_pinning.js` — forces `SecTrustEvaluate`/
  `SecTrustEvaluateWithError`/`SecTrustGetTrustResult` to report
  success (covers the large majority of apps, since almost everything
  built on `NSURLSession`/`CFNetwork` funnels through these), plus
  targeted overrides for custom `didReceiveChallenge:` delegates,
  **TrustKit**, **AFNetworking/Alamofire**-style `AFSecurityPolicy`,
  and `WKWebView` challenge handling.
- `bypass_ssl_pinning_advanced.js` — for the pinning implementations
  that survive a plain `SecTrustEvaluate` patch because the app does
  its **own** comparison afterward, or bypasses Security.framework
  entirely. Covers manual DER-certificate hash pinning, public-key/SPKI
  pinning, native TLS stacks the app bundles itself (OpenSSL/BoringSSL/
  LibreSSL — `SSL_get_verify_result`, `X509_verify_cert`,
  `SSL_CTX_set_verify`), and Apple's newer `Network.framework`
  (`sec_protocol_options_set_verify_block`). **Load this alongside**
  `bypass_ssl_pinning.js`, not instead of it — they patch different
  points in the flow. Two sections of this script (manual cert/pubkey
  pinning) use a documented heuristic rather than a precise patch —
  see the comments at the top of the file for why, and what to do if
  it causes false positives.
- `bypass_proxy_detection.js` — hides system HTTP proxy configuration
  from `CFNetworkCopySystemProxySettings` and
  `NSURLSessionConfiguration.connectionProxyDictionary` reads, for apps
  that refuse to run when they detect a testing proxy.
- `bypass_anti_frida.js` — defeats `ptrace(PT_DENY_ATTACH)`, clears the
  `P_TRACED` sysctl flag, hides `connect()` probes to Frida's default
  ports, and hides `getenv()` checks for `DYLD_INSERT_LIBRARIES`.

These mirror standard, publicly documented iOS pentesting techniques
(the same class of hooks found in tools like Objection and on Frida
CodeShare) — nothing here is iOS-specific malware, and none of it
works against a non-jailbroken device that doesn't already have Frida
injected into it some other way.

### On "bypass everything" — a realistic expectation

There is no version of this tool that can honestly promise to defeat
*every possible* detection check:

- The scripts above cover the common, reusable technique families
  (file/URL/native-call checks, `Security.framework` trust evaluation,
  the well-known pinning libraries). That's the large majority of what
  real apps ship.
- A determined app can implement **fully custom, obfuscated** checks —
  e.g. its own inline assembly checksum of jailbreak paths, checks
  buried in a stripped/obfuscated binary, server-side attestation
  (DeviceCheck/App Attest), or bespoke RASP SDKs. Those require
  reverse-engineering that specific binary (Hopper/IDA/Ghidra +
  `detection_recon.js` as a starting point) — no generic script can
  pre-empt logic that hasn't been written yet.
- "USB debugging," in the Android sense of an ADB toggle apps can
  query, doesn't exist as a concept on iOS. The closest analogues are
  (a) the "Trust This Computer" pairing prompt, which is a one-time
  usbmuxd-level gate this tool already requires you to accept before
  it can talk to the device at all, and (b) **USB Restricted Mode**,
  which is a device lock-screen policy, not something a running app
  can introspect. There's nothing app-facing to bypass there.

Use `detection_recon.js` on a target first — it'll tell you which
technique family you're actually dealing with, so you're not guessing.
