/*
 * bypass_proxy_detection.js
 *
 * Some apps refuse to run (or silently drop traffic) if they detect the
 * device is routed through an HTTP/HTTPS proxy — a common way of
 * detecting testers using Burp/mitmproxy even before SSL pinning comes
 * into play. This hides that configuration from the app's own queries
 * without touching the actual proxy/network settings.
 *
 * Covers:
 *  - CFNetworkCopySystemProxySettings (the standard API almost every
 *    proxy-detection implementation calls, directly or indirectly)
 *  - NSURLSessionConfiguration.connectionProxyDictionary reads
 */

var CFNetworkCopySystemProxySettings = Module.findExportByName("CFNetwork", "CFNetworkCopySystemProxySettings");
if (CFNetworkCopySystemProxySettings) {
    Interceptor.attach(CFNetworkCopySystemProxySettings, {
        onLeave: function (retval) {
            if (retval.isNull()) return;
            try {
                var dict = new ObjC.Object(retval);
                // Report zero configured proxies regardless of the real
                // setting, so a simple "is a proxy configured?" check
                // reads as "no".
                send("[proxy-bypass] Reporting empty proxy settings to caller (real dict had "
                    + dict.count() + " keys)");
                var empty = ObjC.classes.NSDictionary.dictionary();
                retval.replace(empty.handle);
            } catch (e) {
                send("[proxy-bypass] CFNetworkCopySystemProxySettings hook error: " + e);
            }
        }
    });
}

if (ObjC.available) {
    try {
        var configClass = ObjC.classes.NSURLSessionConfiguration;
        var getter = configClass["- connectionProxyDictionary"];
        if (getter) {
            Interceptor.attach(getter.implementation, {
                onLeave: function (retval) {
                    if (!retval.isNull()) {
                        send("[proxy-bypass] connectionProxyDictionary -> reported nil");
                        retval.replace(ptr(0));
                    }
                }
            });
        }
    } catch (e) {}
}

send("[proxy-bypass] Hooks installed.");
