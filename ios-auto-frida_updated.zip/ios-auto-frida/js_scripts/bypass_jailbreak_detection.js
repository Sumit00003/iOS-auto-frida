/*
 * bypass_jailbreak_detection.js
 *
 * Covers the technique families that the large majority of iOS jailbreak
 * detection implementations use (custom, in-house checks, and the
 * common open-source detectors like IOSSecuritySuite / DTTJailbreakDetection
 * tend to combine several of these):
 *
 *   1. File-existence checks for known JB paths/binaries
 *   2. URL-scheme checks (cydia://, sileo://, zbra://, filza://, etc.)
 *   3. Sandbox write-test checks (can the app write outside its container?)
 *   4. fork()/system()/popen() "am I unsandboxed" probes
 *   5. Suspicious dyld image checks (noted, not force-patched — see below)
 *   6. Environment-variable checks (DYLD_INSERT_LIBRARIES, etc.)
 *
 * No script can promise to catch a fully custom/obfuscated check that
 * doesn't call any of the above primitives — those need to be found by
 * reverse-engineering the specific binary. Run enumerate_basic_info.js
 * and detection_recon.js first to see which family the target actually
 * uses before assuming this covers it end-to-end.
 */

// ---------------------------------------------------------------------
// 1) File-existence / stat-family checks
// ---------------------------------------------------------------------
const suspiciousPaths = [
    "/Applications/Cydia.app", "/Applications/Sileo.app", "/Applications/Zebra.app",
    "/Applications/Installer.app", "/Applications/blackra1n.app", "/Applications/FakeCarrier.app",
    "/Applications/Icy.app", "/Applications/IntelliScreen.app", "/Applications/SBSettings.app",
    "/Library/MobileSubstrate/MobileSubstrate.dylib", "/Library/MobileSubstrate/DynamicLibraries",
    "/Library/PreferenceLoader/Preferences", "/Library/dpkg", "/Library/Frameworks/CydiaSubstrate.framework",
    "/bin/bash", "/bin/sh", "/usr/sbin/sshd", "/usr/libexec/sftp-server", "/usr/libexec/ssh-keysign",
    "/usr/bin/ssh", "/usr/bin/scp", "/usr/bin/sftp", "/usr/bin/cycript", "/usr/bin/ldid",
    "/etc/apt", "/etc/ssh/sshd_config", "/private/var/lib/apt", "/private/var/lib/cydia",
    "/private/var/stash", "/private/var/tmp/cydia.log", "/private/var/lib/dpkg/status",
    "/private/etc/apt", "/var/cache/apt", "/var/lib/apt", "/var/lib/cydia", "/var/log/syslog",
    "/.installed_unc0ver", "/.bootstrapped_electra", "/private/var/db/stash"
];

if (ObjC.available) {
    ["fileExistsAtPath:", "fileExistsAtPath:isDirectory:", "isReadableFileAtPath:",
     "isWritableFileAtPath:"].forEach(function (sel) {
        try {
            var method = ObjC.classes.NSFileManager["- " + sel];
            if (!method) return;
            Interceptor.attach(method.implementation, {
                onEnter: function (args) {
                    try { this.path = ObjC.Object(args[2]).toString(); } catch (e) { this.path = null; }
                },
                onLeave: function (retval) {
                    if (!this.path) return;
                    for (var i = 0; i < suspiciousPaths.length; i++) {
                        if (this.path.indexOf(suspiciousPaths[i]) !== -1) {
                            send("[jb-bypass] " + sel + " -> hid " + this.path);
                            retval.replace(ptr(0));
                            return;
                        }
                    }
                }
            });
        } catch (e) {}
    });

    // 2) URL-scheme checks
    try {
        var canOpen = ObjC.classes.UIApplication["- canOpenURL:"];
        Interceptor.attach(canOpen.implementation, {
            onEnter: function (args) {
                try { this.url = ObjC.Object(args[2]).toString(); } catch (e) { this.url = null; }
            },
            onLeave: function (retval) {
                var schemes = ["cydia://", "sileo://", "zbra://", "filza://", "activator://", "undecimus://"];
                for (var i = 0; i < schemes.length; i++) {
                    if (this.url && this.url.indexOf(schemes[i]) === 0) {
                        send("[jb-bypass] canOpenURL -> hid " + this.url);
                        retval.replace(ptr(0));
                        return;
                    }
                }
            }
        });
    } catch (e) {}

    // 3) Sandbox write-test: apps try writing outside their container
    // (e.g. to "/private/jailbreak_test.txt") and treat success as a
    // jailbreak signal.
    try {
        var writeToFile = ObjC.classes.NSString["- writeToFile:atomically:encoding:error:"];
        Interceptor.attach(writeToFile.implementation, {
            onEnter: function (args) {
                try { this.path = ObjC.Object(args[2]).toString(); } catch (e) { this.path = null; }
            },
            onLeave: function (retval) {
                if (this.path && (this.path.indexOf("/private/") === 0 || this.path.indexOf("/var/") === 0 ||
                                   this.path.indexOf("/Applications/") === 0)) {
                    send("[jb-bypass] Blocked out-of-sandbox write test: " + this.path);
                    retval.replace(0); // NO / failure, as a real sandbox would report
                }
            }
        });
    } catch (e) {}
}

// 4) Native path checks + fork()/system()/popen() probes
["stat", "lstat", "access", "open", "opendir"].forEach(function (fn) {
    var addr = Module.findExportByName(null, fn);
    if (!addr) return;
    Interceptor.attach(addr, {
        onEnter: function (args) {
            try { this.path = args[0].readCString(); } catch (e) { this.path = null; }
        },
        onLeave: function (retval) {
            if (!this.path) return;
            for (var i = 0; i < suspiciousPaths.length; i++) {
                if (this.path.indexOf(suspiciousPaths[i]) !== -1) {
                    send("[jb-bypass] " + fn + "() -> hid " + this.path);
                    retval.replace(ptr(-1));
                    return;
                }
            }
        }
    });
});

["fork", "system", "popen"].forEach(function (fn) {
    var addr = Module.findExportByName(null, fn);
    if (!addr) return;
    Interceptor.attach(addr, {
        onLeave: function (retval) {
            // A real sandboxed (non-JB) process generally can't fork() or
            // spawn a shell; forcing failure mirrors that environment for
            // checks that use these as their sole signal.
            send("[jb-bypass] " + fn + "() -> forced failure");
            retval.replace(ptr(-1));
        }
    });
});

// 5) Suspicious dyld image checks — noted only. Force-hiding entries from
// _dyld_image_count()/_dyld_get_image_name() means lying about the
// process's actual loaded-module list, which can crash apps that rely
// on that list being consistent elsewhere. If a target specifically
// enumerates modules looking for tweak/hooking-framework names, that
// needs a purpose-built, app-specific hook rather than a blanket one.
try {
    var count = Process.enumerateModules().length;
    send("[jb-bypass] " + count + " modules currently loaded (dyld image spoofing not applied by default — see comment above)");
} catch (e) {}

// 6) Environment-variable checks
var getenv = Module.findExportByName(null, "getenv");
if (getenv) {
    Interceptor.attach(getenv, {
        onEnter: function (args) {
            try { this.name = args[0].readCString(); } catch (e) { this.name = null; }
        },
        onLeave: function (retval) {
            var suspiciousEnv = ["DYLD_INSERT_LIBRARIES", "DYLD_FRAMEWORK_PATH", "_MSSafeMode"];
            if (this.name && suspiciousEnv.indexOf(this.name) !== -1) {
                send("[jb-bypass] getenv(" + this.name + ") -> hid value");
                retval.replace(ptr(0));
            }
        }
    });
}

send("[jb-bypass] Hooks installed (" + suspiciousPaths.length + " known paths covered).");
