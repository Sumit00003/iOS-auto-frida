/*
 * bypass_anti_frida.js
 *
 * Neutralizes the common ways iOS apps try to detect an attached
 * debugger, Frida's instrumentation, or a proxy/MITM setup, so the
 * rest of an app's behavior can be observed during an authorized
 * assessment.
 *
 * Covers:
 *  - ptrace(PT_DENY_ATTACH) anti-debug trick
 *  - sysctl-based P_TRACED flag checks
 *  - connect() probes to Frida's default ports (27042/27043)
 *  - getenv() probes for injected-library environment variables
 *  - (see bypass_proxy_detection.js for HTTP-proxy-configuration checks)
 */

var ptrace = Module.findExportByName(null, "ptrace");
if (ptrace) {
    Interceptor.attach(ptrace, {
        onEnter: function (args) {
            var request = args[0].toInt32();
            if (request === 31) { // PT_DENY_ATTACH on Darwin
                send("[anti-frida-bypass] Blocked ptrace(PT_DENY_ATTACH)");
                this.deny = true;
            }
        },
        onLeave: function (retval) {
            if (this.deny) retval.replace(0);
        }
    });
}

var sysctl = Module.findExportByName(null, "sysctl");
if (sysctl) {
    Interceptor.attach(sysctl, {
        onEnter: function (args) {
            this.info = args[1];
        },
        onLeave: function (retval) {
            try {
                if (this.info && !this.info.isNull()) {
                    var flagsOffset = 32; // kinfo_proc.kp_proc.p_flag offset (arm64)
                    var flags = this.info.add(flagsOffset).readU32();
                    var P_TRACED = 0x00000800;
                    if (flags & P_TRACED) {
                        this.info.add(flagsOffset).writeU32(flags & ~P_TRACED);
                        send("[anti-frida-bypass] Cleared P_TRACED flag from sysctl() result");
                    }
                }
            } catch (e) {
                // Struct offset can vary by OS version — fail closed
                // (no-op) rather than risk corrupting unrelated memory.
            }
        }
    });
}

var connect = Module.findExportByName(null, "connect");
if (connect) {
    Interceptor.attach(connect, {
        onEnter: function (args) {
            try {
                var sockaddr = args[1];
                var family = sockaddr.add(1).readU8();
                if (family === 2 /* AF_INET */) {
                    var rawPort = sockaddr.add(2).readU16();
                    var port = ((rawPort & 0xff) << 8) | (rawPort >> 8); // network byte order
                    if (port === 27042 || port === 27043) {
                        this.blockFridaPort = true;
                    }
                }
            } catch (e) {}
        },
        onLeave: function (retval) {
            if (this.blockFridaPort) {
                send("[anti-frida-bypass] Hid connect() probe to Frida port");
                retval.replace(-1);
            }
        }
    });
}

var getenv = Module.findExportByName(null, "getenv");
if (getenv) {
    Interceptor.attach(getenv, {
        onEnter: function (args) {
            try { this.name = args[0].readCString(); } catch (e) { this.name = null; }
        },
        onLeave: function (retval) {
            var suspicious = ["DYLD_INSERT_LIBRARIES", "DYLD_FRAMEWORK_PATH"];
            if (this.name && suspicious.indexOf(this.name) !== -1) {
                send("[anti-frida-bypass] getenv(" + this.name + ") -> hid value");
                retval.replace(ptr(0));
            }
        }
    });
}

// Some apps grep their own process's open Mach ports / task info looking
// for Frida's thread names ("gum-js-loop", "gmain", etc). task_threads()
// enumeration is expensive to spoof safely and risks destabilizing the
// process, so it's intentionally not patched here — flag it during recon
// (detection_recon.js) and handle it as an app-specific hook if you
// confirm that's what's happening.

send("[anti-frida-bypass] Hooks installed.");
