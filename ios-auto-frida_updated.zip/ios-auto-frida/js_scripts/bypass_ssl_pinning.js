/*
 * bypass_ssl_pinning.js
 *
 * Disables the SSL/TLS pinning patterns most commonly seen in iOS apps
 * so HTTPS traffic can be inspected through a testing proxy (Burp,
 * mitmproxy, etc.) during an authorized assessment. Only use against
 * apps/devices you are permitted to test.
 *
 * Covers, in order of how commonly apps rely on each:
 *   1. Security.framework: SecTrustEvaluate / SecTrustEvaluateWithError
 *      (catches almost everything built on NSURLSession/CFNetwork,
 *      including most 3rd-party HTTP libraries, since they all funnel
 *      through Security.framework eventually)
 *   2. NSURLSession / NSURLConnection delegate didReceiveChallenge:
 *      overrides (custom pin-comparison logic apps write themselves)
 *   3. TrustKit (a very common drop-in pinning library)
 *   4. AFNetworking / Alamofire's AFSecurityPolicy-style evaluators
 *   5. WKWebView server trust challenge
 */

// ---------------------------------------------------------------------
// 1) Native Security.framework — broadest single win
// ---------------------------------------------------------------------
var SecTrustEvaluate = Module.findExportByName("Security", "SecTrustEvaluate");
if (SecTrustEvaluate) {
    Interceptor.attach(SecTrustEvaluate, {
        onLeave: function (retval) {
            send("[ssl-bypass] SecTrustEvaluate -> forced kSecTrustResultProceed via errSecSuccess");
            retval.replace(0); // errSecSuccess
        }
    });
}

var SecTrustEvaluateWithError = Module.findExportByName("Security", "SecTrustEvaluateWithError");
if (SecTrustEvaluateWithError) {
    Interceptor.attach(SecTrustEvaluateWithError, {
        onLeave: function (retval) {
            send("[ssl-bypass] SecTrustEvaluateWithError -> forced true");
            retval.replace(1);
        }
    });
}

// SecTrustGetTrustResult — some code paths call this instead of/after
// SecTrustEvaluate and branch on the out-parameter.
var SecTrustGetTrustResult = Module.findExportByName("Security", "SecTrustGetTrustResult");
if (SecTrustGetTrustResult) {
    Interceptor.attach(SecTrustGetTrustResult, {
        onEnter: function (args) {
            this.resultPtr = args[1];
        },
        onLeave: function (retval) {
            if (this.resultPtr && !this.resultPtr.isNull()) {
                // kSecTrustResultUnspecified (4) and kSecTrustResultProceed (1)
                // both read as "trusted" to calling code.
                this.resultPtr.writeU32(1);
                send("[ssl-bypass] SecTrustGetTrustResult -> forced kSecTrustResultProceed");
            }
        }
    });
}

// ---------------------------------------------------------------------
// 2) NSURLSession/NSURLConnection delegate challenge handling
// ---------------------------------------------------------------------
if (ObjC.available) {
    var challengeSelectors = [
        "URLSession:didReceiveChallenge:completionHandler:",
        "URLSession:task:didReceiveChallenge:completionHandler:",
        "connection:willSendRequestForAuthenticationChallenge:"
    ];

    Object.keys(ObjC.classes).forEach(function (className) {
        var cls = ObjC.classes[className];
        challengeSelectors.forEach(function (sel) {
            var method = cls["- " + sel];
            if (!method) return;
            try {
                Interceptor.attach(method.implementation, {
                    onEnter: function (args) {
                        send("[ssl-bypass] Intercepted " + sel + " in " + className);
                        try {
                            if (sel.indexOf("completionHandler") !== -1) {
                                var challenge = ObjC.Object(args[sel.indexOf("task:") !== -1 ? 4 : 3]);
                                var handlerArg = sel.indexOf("task:") !== -1 ? args[5] : args[4];
                                var completionHandler = new ObjC.Block(handlerArg);
                                var USE_CREDENTIAL = 0;
                                var credential = ObjC.classes.NSURLCredential.credentialForTrust_(
                                    challenge.protectionSpace().serverTrust()
                                );
                                completionHandler.implementation(USE_CREDENTIAL, credential);
                                // Prevent the app's own (possibly pinning)
                                // logic in this method body from running,
                                // since we've already answered the challenge.
                                this.replace = true;
                            }
                        } catch (e) {
                            send("[ssl-bypass] challenge override failed for " + className + ": " + e);
                        }
                    }
                });
            } catch (e) {}
        });
    });

    // ---------------------------------------------------------------------
    // 3) TrustKit — widely used drop-in pinning library
    // ---------------------------------------------------------------------
    try {
        var TSKPinningValidator = ObjC.classes.TSKPinningValidator;
        if (TSKPinningValidator) {
            var evalMethod = TSKPinningValidator["- evaluateTrust:forHostname:"];
            if (evalMethod) {
                Interceptor.attach(evalMethod.implementation, {
                    onLeave: function (retval) {
                        send("[ssl-bypass] TrustKit evaluateTrust:forHostname: -> forced success (0)");
                        retval.replace(ptr(0)); // TSKTrustEvaluationSuccess
                    }
                });
            }
        }
    } catch (e) {}

    // ---------------------------------------------------------------------
    // 4) AFNetworking / Alamofire-style AFSecurityPolicy
    // ---------------------------------------------------------------------
    try {
        var AFSecurityPolicy = ObjC.classes.AFSecurityPolicy;
        if (AFSecurityPolicy) {
            var evaluateServerTrust = AFSecurityPolicy["- evaluateServerTrust:forDomain:"];
            if (evaluateServerTrust) {
                Interceptor.attach(evaluateServerTrust.implementation, {
                    onLeave: function (retval) {
                        send("[ssl-bypass] AFSecurityPolicy evaluateServerTrust:forDomain: -> forced YES");
                        retval.replace(ptr(1));
                    }
                });
            }
        }
    } catch (e) {}

    // ---------------------------------------------------------------------
    // 5) WKWebView server trust challenges
    // ---------------------------------------------------------------------
    try {
        var WKWebView = ObjC.classes.WKWebView;
        var navDelegateSel = "webView:didReceiveAuthenticationChallenge:completionHandler:";
        Object.keys(ObjC.classes).forEach(function (className) {
            var cls = ObjC.classes[className];
            var method = cls["- " + navDelegateSel];
            if (!method) return;
            try {
                Interceptor.attach(method.implementation, {
                    onEnter: function (args) {
                        send("[ssl-bypass] Intercepted WKWebView challenge in " + className);
                        var challenge = ObjC.Object(args[3]);
                        var completionHandler = new ObjC.Block(args[4]);
                        var USE_CREDENTIAL = 0;
                        var credential = ObjC.classes.NSURLCredential.credentialForTrust_(
                            challenge.protectionSpace().serverTrust()
                        );
                        completionHandler.implementation(USE_CREDENTIAL, credential);
                    }
                });
            } catch (e) {}
        });
    } catch (e) {}
}

send("[ssl-bypass] Hooks installed.");
