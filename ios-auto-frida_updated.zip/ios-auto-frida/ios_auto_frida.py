#!/usr/bin/env python3
"""
__title__     = "iOS Auto Frida - Professional Edition"
__version__   = "2.0"
__license__   = "MIT"

A professional iOS security testing tool that automates Frida instrumentation,
performs static analysis, bypasses common protections, and generates detailed reports.
"""

import sys
import os
import json
import time
import logging
import argparse
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

try:
    import frida
except ImportError:
    print("[!] The 'frida' package is required: pip install frida frida-tools")
    sys.exit(1)

# Import static analyzer
try:
    from static_analyzer import iOSStaticAnalyzer, StaticReport
    STATIC_AVAILABLE = True
except ImportError as e:
    STATIC_AVAILABLE = False
    print(f"[!] Static analyzer not available: {e}")
    print("[!] Run: pip install macholib Pillow")

# ---------------------------------------------------------------------------
# Constants & Configuration
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
JS_DIR = SCRIPT_DIR / "js_scripts"
LOG_DIR = Path("logs")
REPORT_DIR = Path("reports")
TEMP_DIR = Path("temp")
LOG_DIR.mkdir(exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# Map CLI flags to JS script names (without .js)
BYPASS_MAP = {
    "ssl": "bypass_ssl_pinning",
    "ssl_advanced": "bypass_ssl_pinning_advanced",
    "jailbreak": "bypass_jailbreak_detection",
    "frida": "bypass_anti_frida",
    "proxy": "bypass_proxy_detection",
    "recon": "detection_recon",
    "info": "enumerate_basic_info",
}

# ---------------------------------------------------------------------------
# Logging & Color Output
# ---------------------------------------------------------------------------
class Colors:
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    PURPLE = "\033[95m"
    BOLD = "\033[1m"
    END = "\033[0m"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "ios_auto_frida.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)
logging.getLogger().handlers[1].setLevel(logging.WARNING)

# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------
@dataclass
class IOSDeviceInfo:
    id: str
    name: str
    device_type: str
    os_version: Optional[str] = None
    product_type: Optional[str] = None
    arch: Optional[str] = None

@dataclass
class IOSAppInfo:
    identifier: str
    name: str
    pid: Optional[int] = None
    is_running: bool = False

class Severity(Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

# ---------------------------------------------------------------------------
# Import other modules (these are the same as before)
# ---------------------------------------------------------------------------
# For brevity in this response, I'm showing the imports.
# In the actual file, you would have the full implementations of:
# - ConfigManager
# - ReportGenerator 
# - IOSDeviceManager
# - FridaCheckManager
# - IOSAppManager
# - HookLibrary
# - InstrumentationSession

# Since we already defined these in the previous response, I'll show the
# key integration points below.

# ---------------------------------------------------------------------------
# Enhanced Orchestrator with Static Analysis
# ---------------------------------------------------------------------------
class IOSAutoFridaPro:
    def __init__(self, config_path: Optional[Path] = None):
        self.config = self._load_config(config_path)
        self.device_manager = IOSDeviceManager()
        self.report = ReportGenerator()
        self.hooks = HookLibrary()
        self.app_manager: Optional[IOSAppManager] = None
        self.session: Optional[InstrumentationSession] = None
        self.static_report: Optional[StaticReport] = None
        
    def _load_config(self, config_path: Optional[Path]) -> Dict:
        """Load configuration from file or defaults"""
        config = {
            "default_bypasses": ["ssl", "jailbreak", "frida", "proxy"],
            "report": {
                "enabled": False,
                "output_dir": str(REPORT_DIR),
                "include_screenshots": False,
                "include_memory_dump": False,
            },
            "spawn": False,
            "running_only": False,
        }
        if config_path and config_path.exists():
            try:
                with open(config_path, "r") as f:
                    loaded = json.load(f)
                    config.update(loaded)
            except Exception as e:
                print(f"[!] Failed to load config: {e}")
        return config
    
    def run_static_analysis(self, app_bundle_path: Optional[str] = None, 
                           bundle_id: Optional[str] = None) -> Optional[StaticReport]:
        """Run static analysis on the selected app"""
        if not STATIC_AVAILABLE:
            print(f"{Colors.RED}[!] Static analyzer not available. Install with: pip install macholib Pillow{Colors.END}")
            return None
            
        print(f"\n{Colors.BLUE}[*] Running static analysis...{Colors.END}")
        
        # If app bundle path not provided, try to locate it
        if not app_bundle_path:
            # If we have a running app, get its bundle ID
            if self.app_manager and self.app_manager.apps:
                # Use the selected app's bundle ID
                app = self.app_manager.selected_app
                if app:
                    bundle_id = app.identifier
                    print(f"[STATIC] Using bundle ID: {bundle_id}")
            
        # Create analyzer
        analyzer = iOSStaticAnalyzer(Path(self.config["report"]["output_dir"]))
        
        try:
            # If we have a specific path, analyze it
            if app_bundle_path and Path(app_bundle_path).exists():
                report = analyzer.analyze_app(Path(app_bundle_path), bundle_id)
            else:
                # Try to find the app on the device
                # This is a placeholder - in a real implementation, you would
                # use frida to download the app bundle from the device
                print(f"{Colors.YELLOW}[!] App bundle not provided. Static analysis requires the .ipa file or .app bundle.{Colors.END}")
                print(f"{Colors.YELLOW}    Please provide the path with --app-path /path/to/app.ipa{Colors.END}")
                return None
                
            # Generate reports
            html_path = analyzer.generate_html_report()
            json_path = analyzer.generate_json_report()
            
            print(f"{Colors.GREEN}[+] Static analysis complete.{Colors.END}")
            print(f"{Colors.GREEN}[+] HTML report: {html_path}{Colors.END}")
            print(f"{Colors.GREEN}[+] JSON report: {json_path}{Colors.END}")
            
            # Store for later use
            self.static_report = report
            
            # Add findings to main report
            for issue in report.security_issues:
                severity = Severity[issue['severity']] if issue['severity'] in Severity.__members__ else Severity.INFO
                self.report.add_finding(
                    "Static Analysis",
                    severity,
                    issue['issue'],
                    f"Security score: {report.security_score}/100"
                )
                
            return report
            
        except Exception as e:
            print(f"{Colors.RED}[!] Static analysis failed: {e}{Colors.END}")
            return None
        finally:
            analyzer.cleanup()
    
    def run(self, args) -> int:
        """Main orchestration method"""
        self.banner()
        
        # ---- STATIC ANALYSIS (if requested) ----
        if args.static:
            # Static analysis doesn't require a device
            static_report = self.run_static_analysis(args.app_path, args.app)
            if static_report:
                print(f"\n{Colors.CYAN}Static Analysis Summary:{Colors.END}")
                print(f"  Security Score: {static_report.security_score}/100")
                print(f"  Issues Found: {len(static_report.security_issues)}")
                print(f"  Recommendation: {static_report.recommendation[:200]}...")
            
            # If only static analysis, exit
            if args.static_only:
                return 0
        
        # ---- DYNAMIC ANALYSIS (device required) ----
        # Step 1: Detect device
        if not self.device_manager.detect():
            return 1

        # Step 2: Check Frida
        frida_check = FridaCheckManager(self.device_manager)
        if not frida_check.check():
            return 1

        self.device_manager.enrich_with_system_parameters()
        self.report.set_device_info(self.device_manager.device_info)

        # Step 3: Enumerate apps
        self.app_manager = IOSAppManager(self.device_manager)
        apps = self.app_manager.refresh(running_only=args.running_only)
        if not apps:
            print(f"{Colors.RED}[!] No applications found.{Colors.END}")
            return 1

        # Step 4: Select app
        if args.app:
            app = self.app_manager.find_by_identifier(args.app)
            if not app:
                print(f"{Colors.RED}[!] App with bundle ID '{args.app}' not found.{Colors.END}")
                return 1
        else:
            app = self.app_manager.select()
            if not app:
                print(f"{Colors.YELLOW}Cancelled.{Colors.END}")
                return 0

        self.app_manager.selected_app = app
        self.report.set_app_info(app)
        print(f"{Colors.GREEN}[+] Selected: {app.name} ({app.identifier}){Colors.END}")

        # ---- STATIC + DYNAMIC COMBINATION ----
        # If static analysis was requested but we didn't have a path, try to get it
        if args.static and not args.app_path:
            print(f"{Colors.YELLOW}[!] Static analysis requested but no app path provided.{Colors.END}")
            print(f"{Colors.YELLOW}    Static analysis will only work if you provide --app-path /path/to/app.ipa{Colors.END}")
            
            # Ask user if they want to provide it now
            if input("Provide app path now? (y/n): ").lower() == 'y':
                app_path = input("Path to .ipa or .app: ").strip()
                if app_path:
                    self.run_static_analysis(app_path, app.identifier)

        # Step 5: Determine which scripts to load
        if args.script:
            script_path = Path(args.script)
            if not script_path.exists():
                print(f"{Colors.RED}[!] Script not found: {script_path}{Colors.END}")
                return 1
            script_paths = [script_path]
        elif args.bypass_all:
            bypass_flags = ["ssl", "ssl_advanced", "jailbreak", "frida", "proxy"]
            script_paths = self.hooks.select_by_flags(bypass_flags)
        else:
            bypass_flags = []
            if args.ssl_pinning: bypass_flags.append("ssl")
            if args.ssl_advanced: bypass_flags.append("ssl_advanced")
            if args.jailbreak_bypass: bypass_flags.append("jailbreak")
            if args.frida_bypass: bypass_flags.append("frida")
            if args.proxy_bypass: bypass_flags.append("proxy")
            if args.recon: bypass_flags.append("recon")
            if args.info: bypass_flags.append("info")
            
            if not bypass_flags:
                script_paths = self.hooks.interactive_select()
            else:
                script_paths = self.hooks.select_by_flags(bypass_flags)

        if not script_paths:
            print(f"{Colors.YELLOW}No scripts selected — nothing to inject.{Colors.END}")
            # Still generate report if requested
            if args.report:
                self._generate_reports()
            return 0

        # Show which scripts will be loaded
        print(f"{Colors.CYAN}[*] Loading scripts: {', '.join(p.stem for p in script_paths)}{Colors.END}")
        source = self.hooks.combine(script_paths)

        # Step 6: Attach/spawn and load
        self.session = InstrumentationSession(self.device_manager.device)
        if not self.session.attach_or_spawn(app, spawn=args.spawn):
            return 1
        if not self.session.load(source):
            return 1
        self.session.resume()

        print(f"{Colors.GREEN}[+] Hooks loaded into {app.identifier}. Press Ctrl+C to stop.{Colors.END}")

        # Step 7: Generate reports
        if args.report:
            self._generate_reports()

        # Step 8: Wait for user interrupt
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print(f"\n{Colors.CYAN}Detaching...{Colors.END}")
            try:
                self.session.session.detach()
            except Exception:
                pass
            if args.export_session:
                export_path = Path(args.export_session)
                self.session.export_session(export_path)

        return 0
    
    def _generate_reports(self):
        """Generate HTML and JSON reports"""
        print(f"{Colors.BLUE}[*] Generating reports...{Colors.END}")
        
        # Add dynamic analysis findings
        self.report.add_finding(
            "Dynamic Analysis",
            Severity.INFO,
            f"Successfully instrumented with Frida",
            f"Scripts loaded: {len(self.hooks.selected_scripts) if hasattr(self.hooks, 'selected_scripts') else 'unknown'}"
        )
        
        # Add static findings if available
        if self.static_report:
            for issue in self.static_report.security_issues:
                severity = Severity[issue['severity']] if issue['severity'] in Severity.__members__ else Severity.INFO
                self.report.add_finding(
                    "Static Analysis",
                    severity,
                    issue['issue'],
                    f"Security score: {self.static_report.security_score}/100"
                )
        
        html_path = self.report.generate_html()
        json_path = self.report.generate_json()
        print(f"{Colors.GREEN}[+] Report generated: {html_path}{Colors.END}")
        print(f"{Colors.GREEN}[+] JSON report: {json_path}{Colors.END}")
    
    def banner(self) -> None:
        print(f"{Colors.PURPLE}{'=' * 70}{Colors.END}")
        print(f"{Colors.PURPLE}  iOS Auto Frida - Professional Edition v2.0{Colors.END}")
        print(f"{Colors.PURPLE}  Static + Dynamic Analysis for iOS Security Testing{Colors.END}")
        print(f"{Colors.PURPLE}{'=' * 70}{Colors.END}")


# ---------------------------------------------------------------------------
# Command-Line Interface
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="iOS Auto Frida - Professional Edition",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Static analysis only (no device needed)
  python ios_auto_frida.py --static --app-path /path/to/app.ipa

  # Full assessment (static + dynamic)
  python ios_auto_frida.py --static --bypass-all --report --app com.example.app --app-path /path/to/app.ipa

  # Interactive mode
  python ios_auto_frida.py

  # Auto-bypass all protections
  python ios_auto_frida.py --bypass-all --spawn --app com.example.app
        """
    )
    
    # Static analysis
    parser.add_argument("--static", action="store_true", help="Run static analysis on the app bundle")
    parser.add_argument("--static-only", action="store_true", help="Run only static analysis (no device required)")
    parser.add_argument("--app-path", help="Path to .ipa file or extracted .app bundle for static analysis")
    
    # Target selection (same as before)
    parser.add_argument("--app", "-a", help="Target app bundle ID (skip interactive selection)")
    parser.add_argument("--spawn", action="store_true", help="Spawn the app fresh instead of attaching")
    parser.add_argument("--running-only", action="store_true", help="Only show running apps")
    
    # Script selection (same as before)
    parser.add_argument("--bypass-all", action="store_true", help="Load all bypass scripts")
    parser.add_argument("--ssl-pinning", action="store_true", help="Load SSL pinning bypass")
    parser.add_argument("--ssl-advanced", action="store_true", help="Load advanced SSL pinning bypass")
    parser.add_argument("--jailbreak-bypass", action="store_true", help="Load jailbreak detection bypass")
    parser.add_argument("--frida-bypass", action="store_true", help="Load anti-Frida detection bypass")
    parser.add_argument("--proxy-bypass", action="store_true", help="Load proxy detection bypass")
    parser.add_argument("--recon", action="store_true", help="Load detection_recon.js (passive, no patches)")
    parser.add_argument("--info", action="store_true", help="Load enumerate_basic_info.js")
    parser.add_argument("--script", "-s", help="Path to custom .js script")
    
    # Reporting
    parser.add_argument("--report", "-r", action="store_true", help="Generate HTML and JSON reports")
    parser.add_argument("--output-dir", "-o", default="reports", help="Directory for reports")
    parser.add_argument("--config", "-c", help="Load configuration from JSON file")
    parser.add_argument("--export-session", help="Export session state (placeholder)")
    parser.add_argument("--verbose", action="store_true", help="Increase log verbosity")
    
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().handlers[1].setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)

    # Set output directory
    if args.output_dir:
        global REPORT_DIR
        REPORT_DIR = Path(args.output_dir)
        REPORT_DIR.mkdir(parents=True, exist_ok=True)

    # If static-only, we don't need device
    if args.static_only:
        from static_analyzer import iOSStaticAnalyzer
        analyzer = iOSStaticAnalyzer(REPORT_DIR)
        try:
            report = analyzer.analyze_app(Path(args.app_path) if args.app_path else None, args.app)
            html_path = analyzer.generate_html_report()
            json_path = analyzer.generate_json_report()
            print(f"\n{Colors.GREEN}[+] Static analysis complete.{Colors.END}")
            print(f"{Colors.GREEN}[+] HTML report: {html_path}{Colors.END}")
            print(f"{Colors.GREEN}[+] JSON report: {json_path}{Colors.END}")
            print(f"{Colors.CYAN}Security Score: {report.security_score}/100{Colors.END}")
            sys.exit(0)
        except Exception as e:
            print(f"{Colors.RED}[!] Static analysis failed: {e}{Colors.END}")
            sys.exit(1)
        finally:
            analyzer.cleanup()

    # Run full tool
    tool = IOSAutoFridaPro(Path(args.config) if args.config else None)
    sys.exit(tool.run(args))

if __name__ == "__main__":
    main()
